using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XYCM.Tools;
using System;

public class test_wym01 : MonoBehaviour
{
    
    string[][] s = new string[2][];

    int num = 0;
    PlayerModel data = PlayerModel.Data;
    // Start is called before the first frame update
    void Start()
    {
        Action a = new Action(TestMethod1);

        MathTools mt = new MathTools();
        Debug.Log("���Ľ��Ϊ��"+mt.getRandomFloat(0f, 6f, 2));

        Computer computer = new Computer();

        Debug.Log("����Ϊ"+computer.GetPerformance(a)+"����");

        
  
        data.LoadLevelData("001");
        print(data.peer.Age);
        print(data.doctor.Name);
        print(data.patient.Image);



        say();
        data.NextDialog();
        say();
        data.NextDialog();
        say();
        data.NextDialog();
        say();
    }
    
    void say()
    {
        num += 1;
        Debug.Log("��"+num+"��");
        print(data.nowDialogTxt);
        //print(data.nowSprites[0] + "," + data.nowSprites[1]);
        
    }

    
    void TestMethod0()//���������ܵ����
    {
       /* System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch();
        timer.Start();
        //ArrayList al = new ArrayList(4);
        TestMethod1();
        //string[] s = new string[4];
        timer.Stop();
        Debug.Log(timer.Elapsed.TotalMilliseconds);*/
    }
    void TestMethod1()//���������ܵ����
    {
      
    }
    void TestMethod2()//���������ܵ����
    {
        ArrayList al = new ArrayList(4);
    }
   
}
