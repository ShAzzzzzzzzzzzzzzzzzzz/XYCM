using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//该脚本给玩家角色挂载
public class JointedArmWalk : MonoBehaviour
{
    private Vector3 pos;
    public float speed;
    // Start is called before the first frame update


    // Update is called once per frame
    void Update()
    {
        if(JointedArm.Ifwalk())//检测到摇杆正在被使用
        {
            pos = new Vector3(JointedArm.targetX,0,JointedArm.targetY);
            float y = Camera.main.transform.rotation.eulerAngles.y;
            pos = Quaternion.Euler(0, y, 0) * pos;
            //GetComponent<Transform>().position+=JointedArm.targetWay()*speed*deltaTime;
            GetComponent<Transform>().position += pos*speed*Time.deltaTime;

        }
    }
}
