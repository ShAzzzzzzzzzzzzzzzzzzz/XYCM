using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Transform player;

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(player.position);
        transform.position = new Vector3(player.position.x-71, player.position.y+295, player.position.z-699);
    }
}
