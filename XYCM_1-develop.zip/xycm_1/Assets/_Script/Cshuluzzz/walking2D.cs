using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class walking2D: MonoBehaviour
{
    private Animator animator;

    void Start() {
        animator=GetComponent<Animator>();
    }

    void Update() {
        //点击
        if(ClickWalking.ison==true && ClickWalking.ifleft==false)
        {
            animator.SetBool("right",true);
            GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, 0, 0));
        }
        else if(ClickWalking.ison==true && ClickWalking.ifleft==true){
            animator.SetBool("left",true);
            GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, 180, 0));
            //Debug.Log(1);

        }
        else{
            animator.SetBool("left",false);
            animator.SetBool("right",false);
            GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, 0, 0));
        }
    }
}