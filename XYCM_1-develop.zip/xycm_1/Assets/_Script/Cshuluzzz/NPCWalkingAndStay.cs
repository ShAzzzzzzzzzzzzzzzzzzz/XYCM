using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


                                      //挂载给NPC
public class NPCWalkingAndStay : MonoBehaviour
{

    
    private Vector3 TargetPosition; //目标位置
    private Vector3 ObjectPosition; //获取NPC当前位置
    private Vector3 shuPosition;    //前进方向
    public float speed;
    private float step;
    public static bool ison; //NPC是否行走
    
    private double testdouble;

    public double IntervalTime; //间隔时间
    private double time; //记录过去的时间
    private bool changeTar; //是否获取新的目标 false时表现为获取新的

    // Update is called once per frame
    void Update()
    {
        step = speed * Time.deltaTime;//速度
        ObjectPosition=GetComponent<Transform>().position; //获取当前位置
        
        if(time>=IntervalTime)                  //间隔到了则新建一个位置进行移动
        {
            if(changeTar == false){
                TargetPosition = new Vector3(Random.Range(0,1000),GetComponent<Transform>().position.y,Random.Range(0,1000)); //时间到了生成一个新的目标地点
                ison = true;
                changeTar = true;
            }
            
            //Debug.Log(TargetPosition);
            if(ison)
            {
                GetComponent<Transform>().position = Vector3.MoveTowards(ObjectPosition,TargetPosition,step);

                testdouble = Mathf.Abs(TargetPosition.magnitude-ObjectPosition.magnitude);
                //Debug.Log(testdouble);
                if(testdouble<1)
                {
                    ison=false;
                    time =0;
                    changeTar=false;
                }
            }
        }
        else{
            time +=1 ;
            //Debug.Log(time);
        }

   
        // if(ison)
        // {
            
        // }
        
        // //获取当前物体所在位置
        // //Debug.Log("现在在"+ObjectPosition);
        // if(Input.GetMouseButtonDown(0)){
        //     TargetPosition = Input.mousePosition;
        //     if(GetComponent<Transform>().position.x<Input.mousePosition.x){
                
        //     }
        //     else{
               
        //     }
        //     //Debug.Log(ifleft);
        //     ison=true;
        //     //Debug.Log(TargetPosition);
        // }
        
    }
}
