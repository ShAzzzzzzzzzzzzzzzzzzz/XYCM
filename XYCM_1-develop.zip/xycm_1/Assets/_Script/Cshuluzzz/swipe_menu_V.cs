using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class swipe_menu_V : MonoBehaviour
{

    public GameObject scrollbar;
    float scroll_pos = 0;
    float[] pos;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        pos = new float[transform.childCount];
        float distance = 1f/ (pos.Length - 1f);
        Debug.Log(distance);
        for( int i=0;i<pos.Length;i++)
        {
            pos[i] = distance * (pos.Length-1-i);
        }
        if(Input.GetMouseButton(0)){
            scroll_pos = scrollbar.GetComponent<Scrollbar>().value;
        }
        else{
            for( int i=0;i<pos.Length;i++){
                if(scroll_pos<pos[i]+(distance/2) && scroll_pos>pos[i]-(distance/2)){
                    scrollbar.GetComponent<Scrollbar>().value = Mathf.Lerp(scrollbar.GetComponent<Scrollbar>().value,pos[i],0.1f);
                }

            }
        }
        //大小变化
        for(int i=0;i<pos.Length;i++){
            if(scroll_pos<pos[i]+(distance/2) && scroll_pos>pos[i]-(distance/2)){
                transform.GetChild(i).localScale = Vector2.Lerp(transform.GetChild(i).localScale,new Vector2(1f,1f),0.1f);
                for( int a=0;a<pos.Length;a++){
                    if(a!=i){
                        transform.GetChild(a).localScale = Vector2.Lerp(transform.GetChild(a).localScale,new Vector2((1-Mathf.Abs(pos[a]+(distance/2)-scroll_pos)*2),(1-Mathf.Abs(pos[a]+(distance/2)-scroll_pos)*2)),0.1f);
                        
                    }
                }
            }
        }
        //透明
        GameObject[] guntongs = GameObject.FindGameObjectsWithTag("滚筒");
        Debug.Log(guntongs);
        for(int i=0;i<pos.Length;i++){
            if(scroll_pos<pos[i]+(distance/2) && scroll_pos>pos[i]-(distance/2)){
                guntongs[i].GetComponent<Image>().color = new Color(1,1,1,1);
                for( int a=0;a<pos.Length;a++){
                    if(a!=i){
                        //透明化
                        guntongs[a].GetComponent<Image>().color = new Color(1,1,1,1-Mathf.Abs(pos[a]+(distance/2)-scroll_pos)*5); 
                        //移动位置 使对齐
                        //guntongs[a].GetComponent<Transform>().position.x=guntongs[a].GetComponent<Transform>().position.x -10;

                    }
                }
            }
        }

        //test
        //GameObject.Find("123123").GetComponent<Image>().color = new Color(1,1,1,0);
    }
}