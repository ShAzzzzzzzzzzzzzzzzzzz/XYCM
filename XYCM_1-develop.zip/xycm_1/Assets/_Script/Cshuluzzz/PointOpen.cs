using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointOpen : MonoBehaviour
{
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void click(){
        gameObject.SetActive(true);   
    }
    private IEnumerator Delay()
    {
        yield return new WaitForSeconds(10000.5f);//延时n帧再继续向下执行
    }
    private IEnumerator Delay1()
    {
        yield return new WaitForSeconds(10000.5f);//延时n帧再继续向下执行
    }
}
