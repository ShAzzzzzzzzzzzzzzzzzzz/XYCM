using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Buttom_SwitchScene1 : MonoBehaviour
{
    //private float time =10000; 
    //private float timer =0;
    // Start is called before the first frame update
    public string scene;
    void Start() {
        Button btn = transform.GetComponent<Button>();

        btn.onClick.AddListener(doeventListener);

    }

    // Update is called once per frame
 
    
    void doeventListener(){
        Invoke("eventListener",0.5f);
    }
    void eventListener() {
        StartCoroutine("Delay");//开始协程
       
        
        SceneManager.LoadScene(scene,LoadSceneMode.Single);
    }
    private IEnumerator Delay()
    {
        yield return new WaitForSeconds(10000.5f);//延时n帧再继续向下执行
    }
    private IEnumerator Delay1()
    {
        yield return new WaitForSeconds(10000.5f);//延时n帧再继续向下执行
    }
}
