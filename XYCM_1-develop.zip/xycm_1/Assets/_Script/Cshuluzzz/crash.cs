using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//给障碍物挂载
public class crash : MonoBehaviour
{
    public GameObject player;
    private float x;
    
    private float z;
    // Start is called before the first frame update


    void OnCollisionEnter(Collision other){   //发生碰撞
        if(other.gameObject.tag =="Player")
        {
            // s=player.GetComponent<JointedArmWalk>().speed;
            // player.GetComponent<JointedArmWalk>().speed=0;//停止运动
            //Debug.Log("crash");
            x = player.transform.position.x - GetComponent<Transform>().position.x;
            
            z = player.transform.position.z - GetComponent<Transform>().position.z;
            player.transform.position +=new Vector3(2*x,0,4*z);
            //player.transform.position.z += player.transform.position.z - GetComponent<Transform>().position.z;
        }
        
    }

}
