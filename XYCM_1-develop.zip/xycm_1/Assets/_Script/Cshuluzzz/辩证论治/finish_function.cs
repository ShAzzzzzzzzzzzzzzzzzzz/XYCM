using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class finish_function : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void click(){
        DifferentiationController.HideMe(); 
        PrescriptionController.ShowMe();
    }
}
