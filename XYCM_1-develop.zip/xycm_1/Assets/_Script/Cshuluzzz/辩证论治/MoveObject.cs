using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
public class MoveObject : MonoBehaviour
{

    public GameObject targetObject;//目标物体
    private float x;
    private float y;
    private bool ifdrag;
    public bool catched;
    private Vector3 OriginalPosition;
    public GameObject tishi;//吸附后使对应的提示出现
    public GameObject[] WrongTargetObjects;

    void Start() {
        catched=false;
        x=GetComponent<Transform>().position.x;
        y=GetComponent<Transform>().position.y;
        OriginalPosition=GetComponent<Transform>().position;
        //Debug.Log(x);
        //Debug.Log(y);
        //Debug.Log(targetObject.transform.position);
        //Debug.Log(GetComponent<Transform>().position);
        //GetComponent<Transform>().position=targetObject.transform.position;
        
    }

    void Update() {
        //Debug.Log(ifdrag)
        //检测鼠标是否选中物体
        if(Input.GetMouseButtonDown(0) && catched==false)
        {
            if(Input.mousePosition.x>x-40 && Input.mousePosition.x<x+40 &&Input.mousePosition.y>y-3 && Input.mousePosition.y<y+3)
            {
                ifdrag = true;
            //Debug.Log(Input.mousePosition);
            }
        }
        //拖拽物体
        if( ifdrag==true)
        {
            GetComponent<Transform>().position=Input.mousePosition;
            //Debug.Log(GetComponent<Transform>().position);

        }
        //拖拽结束 检测是否对接成功
        //targetObject.Transform.position
        if(Input.GetMouseButtonUp(0))
        {
            ifdrag=false;

            //与正确目标对接成功后 出现提示
            //Debug.Log(2);
            if( GetComponent<Transform>().position.x>targetObject.transform.position.x-50 && 
                GetComponent<Transform>().position.x<targetObject.transform.position.x+50 &&
                GetComponent<Transform>().position.y>targetObject.transform.position.y-10 &&
                GetComponent<Transform>().position.y<targetObject.transform.position.y+10 )
            {
                GetComponent<Transform>().position=targetObject.transform.position;
                catched=true;
                tishi.SetActive(true);
            }
            else//检测是否与错误目标对接
            {
                //GetComponent<Transform>().position=OriginalPosition;
                for(var i=0;i<WrongTargetObjects.Length;i++)
                {
                    //Debug.Log(1);
                    if( GetComponent<Transform>().position.x>WrongTargetObjects[i].transform.position.x-50 && 
                        GetComponent<Transform>().position.x<WrongTargetObjects[i].transform.position.x+50 &&
                        GetComponent<Transform>().position.y>WrongTargetObjects[i].transform.position.y-10 &&
                        GetComponent<Transform>().position.y<WrongTargetObjects[i].transform.position.y+10)
                    {
                        Debug.Log(1);
                        GetComponent<Transform>().position=WrongTargetObjects[i].transform.position;
                        catched=true;
                    }                      
                }
                if(catched==false)
                {
                    GetComponent<Transform>().position=OriginalPosition;
                }
            } 

            
            


            
            
        }


    }

 
   
}