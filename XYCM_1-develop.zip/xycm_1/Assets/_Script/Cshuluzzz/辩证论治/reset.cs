using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class reset : MonoBehaviour
{
    private float x;
    private float y;
    // Start is called before the first frame update
    void Start()
    {
        x=GetComponent<Transform>().position.x;
        y=GetComponent<Transform>().position.y;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void click(){
        //Debug.Log(x);
        //Debug.Log(y);
        GetComponent<MoveObject>().catched=false;
        GetComponent<Transform>().position=new Vector3(x,y,GetComponent<Transform>().position.z);

    }
}
