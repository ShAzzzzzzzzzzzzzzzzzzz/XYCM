using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Finish : MonoBehaviour
{
    private GameObject[] objects ;
    //private bool pass;
    //private bool iffor;//检测for循环是否进行过至少一次（防止一开始按钮就出现）
    public GameObject finish;
    private int i;
    // Start is called before the first frame update
    void Start()
    {
        i=0;
        var all = Resources.FindObjectsOfTypeAll<GameObject>();
        foreach (GameObject item in all)
        {
            if (item.gameObject.tag == "tishi")
            {
                i++;
                //Debug.Log(i);
                Debug.Log(item.gameObject.name);
            }
        }
        i=i/2;
        //Debug.Log(i);
    }

    // Update is called once per frame
    void Update()
    {
        
        objects=GameObject.FindGameObjectsWithTag("tishi");
        //Debug.Log(i);
        if(objects.Length==i)
        {
            finish.SetActive(true);
        }
        
        
    }
}
