using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClickWalking : MonoBehaviour
{

    
    private Vector3 TargetPosition;
    private Vector3 ObjectPosition;
    private Vector3 shuPosition;
    public float speed;
    private float step;
    public static bool ison;
    public static bool ifleft;
    private double testdouble;
    

    // Update is called once per frame
    
    

    void Update()
    {
        step = speed * Time.deltaTime;//速度
        if(ison)
        {
            GetComponent<Transform>().position=Vector3.MoveTowards(ObjectPosition,TargetPosition,step);
        }
        ObjectPosition=GetComponent<Transform>().position;
        //获取当前物体所在位置
        //Debug.Log("现在在"+ObjectPosition);
        if(Input.GetMouseButtonDown(0)){
            TargetPosition = Input.mousePosition;
            if(GetComponent<Transform>().position.x<Input.mousePosition.x){
                ifleft=false;
            }
            else{
                ifleft=true;
            }
            //Debug.Log(ifleft);
            ison=true;
            //Debug.Log(TargetPosition);
        }
        testdouble =Mathf.Abs(TargetPosition.magnitude-ObjectPosition.magnitude) ;
        if(testdouble<1)
        {
            
            //Debug.Log(testdouble);
            ison=false;
        }
        
        
        

    
        
        //Debug.Log("移动到了"+shuPosition);
        
       

    }


}
