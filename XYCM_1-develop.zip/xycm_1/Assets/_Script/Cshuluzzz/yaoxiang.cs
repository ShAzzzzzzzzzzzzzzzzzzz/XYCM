using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class yaoxiang : MonoBehaviour
{
    public GameObject yx;
    public GameObject button1;
    public GameObject button2;
    public GameObject button3;
    public GameObject button4;
    public GameObject button5;
    public GameObject button6;
    public GameObject button7;
    public GameObject button8;
    public GameObject button9;
    public GameObject button10;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        button1.transform.rotation = yx.transform.rotation;
        button1.transform.position= new Vector3 (yx.transform.rotation.x+960,yx.transform.rotation.y+580,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button1.transform.rotation.y>0.26 || button1.transform.rotation.y<-0.26)
        {
            button1.SetActive(false);
            
        }
        if(button1.transform.rotation.y<0.26 && button1.transform.rotation.y>-0.26)
        {
            button1.SetActive(true);
        }

        button2.transform.rotation = yx.transform.rotation;
        button2.transform.position= new Vector3 (yx.transform.rotation.x+750,yx.transform.rotation.y+401,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button2.transform.rotation.y>0.26 || button2.transform.rotation.y<-0.26)
        {
            button2.SetActive(false);
            
        }
        if(button2.transform.rotation.y<0.26 && button2.transform.rotation.y>-0.26)
        {
            button2.SetActive(true);
        }

        button3.transform.rotation = yx.transform.rotation;
        button3.transform.position= new Vector3 (yx.transform.rotation.x+1177,yx.transform.rotation.y+406,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button3.transform.rotation.y>0.26 || button3.transform.rotation.y<-0.26)
        {
            button3.SetActive(false);
            
        }
        if(button3.transform.rotation.y<0.26 && button3.transform.rotation.y>-0.26)
        {
            button3.SetActive(true);
        }

        button4.transform.rotation = yx.transform.rotation;
        button4.transform.position= new Vector3 (yx.transform.rotation.x+743,yx.transform.rotation.y+229,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button4.transform.rotation.y>0.26 || button4.transform.rotation.y<-0.26)
        {
            button4.SetActive(false);
            
        }
        if(button4.transform.rotation.y<0.26 && button4.transform.rotation.y>-0.26)
        {
            button4.SetActive(true);
        }

        button5.transform.rotation = yx.transform.rotation;
        button5.transform.position= new Vector3 (yx.transform.rotation.x+1178,yx.transform.rotation.y+219,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button5.transform.rotation.y>0.26 || button5.transform.rotation.y<-0.26)
        {
            button5.SetActive(false);
            
        }
        if(button5.transform.rotation.y<0.26 && button5.transform.rotation.y>-0.26)
        {
            button5.SetActive(true);
        }

        button6.transform.rotation = yx.transform.rotation;
        button6.transform.position= new Vector3 (yx.transform.rotation.x+964,yx.transform.rotation.y+417,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button6.transform.rotation.y>0.26 || button6.transform.rotation.y<-0.26)
        {
            button6.SetActive(false);
            
        }
        if(button6.transform.rotation.y<0.26 && button6.transform.rotation.y>-0.26)
        {
            button6.SetActive(true);
        }

        button6.transform.rotation = yx.transform.rotation;
        button6.transform.position= new Vector3 (yx.transform.rotation.x+964,yx.transform.rotation.y+417,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button6.transform.rotation.y>0.26 || button6.transform.rotation.y<-0.26)
        {
            button6.SetActive(false);
            
        }
        if(button6.transform.rotation.y<0.26 && button6.transform.rotation.y>-0.26)
        {
            button6.SetActive(true);
        }

        button7.transform.rotation = yx.transform.rotation;
        button7.transform.position= new Vector3 (yx.transform.rotation.x+964,yx.transform.rotation.y+320,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button7.transform.rotation.y>0.26 || button7.transform.rotation.y<-0.26)
        {
            button7.SetActive(false);
            
        }
        if(button7.transform.rotation.y<0.26 && button7.transform.rotation.y>-0.26)
        {
            button7.SetActive(true);
        }

        button8.transform.rotation = yx.transform.rotation;
        button8.transform.position= new Vector3 (yx.transform.rotation.x+964,yx.transform.rotation.y+216,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button8.transform.rotation.y>0.26 || button8.transform.rotation.y<-0.26)
        {
            button8.SetActive(false);
            
        }
        if(button8.transform.rotation.y<0.26 && button8.transform.rotation.y>-0.26)
        {
            button8.SetActive(true);
        }

        button9.transform.rotation = yx.transform.rotation;
        button9.transform.position= new Vector3 (yx.transform.rotation.x+780,yx.transform.rotation.y+412,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button9.transform.rotation.y<0.94 && button9.transform.rotation.y>-0.94)
        {
            
            button9.SetActive(false);
            
        }
        if(button9.transform.rotation.y>0.94 || button9.transform.rotation.y<-0.94)
        {
            button9.transform.rotation = Quaternion.Euler(0,0,0);
            button9.SetActive(true);
        }

        button10.transform.rotation = yx.transform.rotation;
        button10.transform.position= new Vector3 (yx.transform.rotation.x+1125,yx.transform.rotation.y+412,yx.transform.rotation.z);
        //Debug.Log(transform.rotation.y);
        if(button10.transform.rotation.y<0.94 && button10.transform.rotation.y>-0.94)
        {
            
            button10.SetActive(false);
            
        }
        if(button10.transform.rotation.y>0.94 || button10.transform.rotation.y<-0.94)
        {
            button10.transform.rotation = Quaternion.Euler(0,0,0);
            button10.SetActive(true);
        }
    }
}
