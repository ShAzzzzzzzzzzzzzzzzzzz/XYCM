using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//挂载给主角 time不用加
public class walking : MonoBehaviour
{
    private Animator animator;
    public double Time;
    private double time;
    private bool right;
    private bool left;
    private bool daiji;

    void Start() {
        animator=GetComponent<Animator>();
    }

    void Update() {
        // //点击
        // if(ClickWalking.ison==true && ClickWalking.ifleft==false)
        // {
        //     animator.SetBool("right",true);
        //     GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, 0, 0));
        // }
        // else if(ClickWalking.ison==true && ClickWalking.ifleft==true){
        //     animator.SetBool("left",true);
        //     GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, 180, 0));
        //     //Debug.Log(1);

        // }
        // else{
        //     animator.SetBool("left",false);
        //     animator.SetBool("right",false);
        //     GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, 0, 0));
        // }

        //摇杆

        //the most important thinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnng!
        float y = Camera.main.transform.rotation.eulerAngles.y;
        //the most important thinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnng!
        //the most important thinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnng!
        //the most important thinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnng!

        if(JointedArm.ifwalk && JointedArm.targetX>=0 )
        {
            animator.SetBool("right",true);
            right = true;
            GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, y, 0));
        }
        else if(JointedArm.ifwalk && JointedArm.targetX<0 )
        {
            animator.SetBool("left",true);
            left = true;
            GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0, y+180, 0));
        }
        else 
        {
            animator.SetBool("left",false);
            animator.SetBool("right",false);
            right = false;
            left = false;
            GetComponent<Transform>().rotation=Quaternion.Euler(new Vector3(0,y, 0));
        }
        //待机
        if(time>=Time && right == false && left == false &&daiji==false){
            animator.SetBool("walking",true);
            time=0;
            daiji=true;
            //Debug.Log(daiji);
        }
        else if(right == false && left == false )
        {
            time += 1;
        }
        if(daiji ==true && time==800)
        {
            animator.SetBool("walking",false);
            daiji=false;
            time=0;
            //Debug.Log(1);
        }
        
      

    }
}

