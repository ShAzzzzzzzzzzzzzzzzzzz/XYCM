using System;
using System.Collections;
using System.Collections.Generic;
using _Script.Other;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.UIElements;
using Button = UnityEngine.UI.Button;
using Image = UnityEngine.UI.Image;
public class ClueView : MonoBehaviour
{
    public Button lastBtn;
    public Button nextBtn;
    public Text content;

    public void UpdateInfo()
    {
        
    }
    
    /// <summary>
    /// ��ʾ���е�������Ϣ
    /// </summary>
    /// <param name="tips"></param>
    public void ShowTip(string[] tips)
    {
        Transform choose = transform.Find("Choose");
        Transform clue = transform.Find("Clue");
        if (tips.Length > 3)
        {
            Debug.Log($"��������Ϊ{tips.Length},��������3");
            return;
        }
        
        
        for (int i = 0; i < tips.Length; i++)
        {
            Transform c = choose.GetChild(i);
            Transform c1 = clue.GetChild(i);
            c.GetComponentInChildren<Text>().text = tips[i];
            c.gameObject.SetActive(true);
            c1.GetComponentInChildren<Text>().text = tips[i];
            // ����ק�ĺ���
            c.AddComponent<DragMove>();
            c.GetComponent<DragMove>().begin += TipDrapBegin;
            c.GetComponent<DragMove>().ondrog += TipOnDrap;
            c.GetComponent<DragMove>().endDrag += TipEndDrap;
        }
    }

    /// <summary>
    /// ��¼��ʼ�϶���λ��
    /// </summary>
    private Vector2 beginDrapPosition;
    
    /// <summary>
    /// ������ʼ�϶�ʱ����
    /// </summary>
    /// <param name="eventData">UI�¼�ϵͳ�Ĳ���</param>
    public void TipDrapBegin(PointerEventData eventData)
    {
        Transform t = eventData.pointerDrag.transform;        
        beginDrapPosition = new Vector2(t.position.x,t.position.y);
    }

    /// <summary>
    /// ���������϶�ʱ����
    /// </summary>
    public void TipOnDrap(PointerEventData eventData)
    {
        eventData.pointerDrag.transform.position = eventData.position;
        string tipName = eventData.pointerDrag.name;
        
        // �ҵ�ͬ����Clue��transform���
        Transform target;
        Transform clue = transform.Find("Clue");

        target = clue.GetChild(int.Parse(tipName));
        
        // �������transform�ľ���
        float distence = Vector3.Distance(target.position, eventData.pointerDrag.transform.position);
        if (distence < 100f)
        {
            target.gameObject.SetActive(true);
            Color color = target.GetComponent<Image>().color;
            color.a = 0.5f;
            target.GetComponent<Image>().color = color;
            
        }
        else
        {
            target.gameObject.SetActive(false);
            Color color = target.GetComponent<Image>().color;
            color.a = 1f;
            target.GetComponent<Image>().color = color;
        }


    }
    // ��������ݱ��浽������
    public List<string> saveData;
    /// <summary>
    /// �����϶�����ʱ����
    /// </summary>
    /// <param name="eventData"></param>
    public void TipEndDrap(PointerEventData eventData)
    {
        //��������ص���ʼλ��
        eventData.pointerDrag.transform.position = beginDrapPosition;

        // �����͹̶�ס������λ��
        string tipName = eventData.pointerDrag.name;
        Transform target;
        Transform clue = transform.Find("Clue");
        target = clue.Find(tipName);
        Color color = target.GetComponent<Image>().color;

        // С��0.001f��ʾѡ�е�ǰ
        if (Math.Abs(color.a - 0.5f) < 0.001f)
        {
            eventData.pointerDrag.SetActive(false);
            color.a = 1f;
            target.GetComponent<Image>().color = color;
            
            saveData.Add(eventData.pointerDrag.transform.GetChild(0).GetComponent<Text>().text);

            SUnDo.Push(new TipOprate(tipName,true));
        }
    }

    /// <summary>
    /// �����б�
    /// </summary>
    public struct TipOprate
    {
        public TipOprate(string id,bool o)
        {
            Id = id;
            Oprate = o;
        }
        public string Id;
        public bool Oprate; // 1 ��ʾѡ��, 0 ��ʾȡ��ѡ��
    }
    public Stack<TipOprate> SUnDo = new Stack<TipOprate>(); 
    public void UnDoBtn()
    {

        if (SUnDo.Count > 0)
        {
            // ��ȡ�ϴε�Stack�Ĳ���
            TipOprate t = SUnDo.Pop();
            CheckTipActive(t.Id);
            SReDo.Push(new TipOprate(t.Id,!t.Oprate));
        }
    }
    public Stack<TipOprate> SReDo = new Stack<TipOprate>();

    public void ReDoBtn()
    {

        if (SReDo.Count > 0)
        {
            TipOprate s = SReDo.Pop();
            CheckTipActive(s.Id);
            SUnDo.Push(new TipOprate(s.Id,!s.Oprate));
        }
    }
    
    
    private void CheckTipActive(string tipName)
    {
        GameObject Choose = transform.Find("Choose/"+tipName).gameObject;
        GameObject Clue = transform.Find("Clue/"+tipName).gameObject;
        Choose.SetActive(!Choose.activeSelf);
        Clue.SetActive(!Clue.activeSelf);
        
    }
    
    // ����ȷ����ť����ʾ������
    public void ShowEnsure(bool show)
    {
        transform.Find("Ensure").gameObject.SetActive(show);
    }
    
    // ��������������
    public void HideAllClue()
    {
        Transform clue = transform.Find("Clue");
        for (int i = 0; i < clue.childCount; i++)
        {
            clue.GetChild(i).gameObject.SetActive(false);
        }
    }
    
}
