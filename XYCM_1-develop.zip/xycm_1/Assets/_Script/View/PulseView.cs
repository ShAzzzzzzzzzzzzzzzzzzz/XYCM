using System;
using System.Collections;
using System.Collections.Generic;
using _Script.Other;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.UIElements;
using Button = UnityEngine.UI.Button;
using Image = UnityEngine.UI.Image;

public class PulseView : MonoBehaviour
{
    /// <summary>
    /// �������
    /// View��ͼ��
    /// �ܷ�����UpdateInfo()
    /// </summary>

    public Button backBtn;
    public Button gotoRecordBtn;
    public Sprite dialogBg;
    public Text dialogText;
    public Text nowName;//����˵���Ľ�ɫ������
    public Sprite character1;//����
    public Sprite character2;//�ಽ��
    
    // ����ѡ������ݷ�Χ
    public int AllowClues = 1;
    public string[] clues = new[] {"����", "����", "����"};

    public string choiceClues;
    
    private void Start()
    {
        backBtn.onClick.AddListener(() =>
        {
            PulseController.HideMe();
            ClueController.HideMe();
            QuestionController.ShowMe();
        });
        gotoRecordBtn.onClick.AddListener(() =>
        {
            PulseController.HideMe();
            ClueController.HideMe();
            DifferentiationController.ShowMe();
        });
        ClueController.ShowMe();
        ClueController.ShowLast();
        ClueController.Controller.HideAllClue();
        ClueController.Controller.SetTip(clues);
        ClueController.Controller.allowChoiceNum = AllowClues;
        ClueController.Controller.HideUnReDo();
    }
    
    /// <summary>
      ///  ��ʾ�������������Ϣ
      /// </summary>
      /// <param name="title">�����ַ�������</param>
      public void ShowTitle(string title)
      {
          Transform t = transform.Find("LeftAn/Title");
          t.GetComponentInChildren<Text>().text = title;

      }
    
    // �����Ƿ�ѡ�����
    public bool ChoiceOver()
    {
        if (ClueController.Controller.GetChoice().Count >= AllowClues)
        {
            return true;
        }

        return false;
    }
    
    public void ShowTip()
      {
          ClueController.ShowMe();
      }

    private void Update()
    {
        // ѡ����Ͼ�������ʾ������
        if (ChoiceOver())
        {
            choiceClues = ClueController.Controller.GetChoice()[0];
            ClueController.Controller.HideAllClue();
            ClueController.Controller.SetTip(clues);
            List<string> s = new List<string>();
            s.Add(choiceClues);
            ClueController.Controller.ShowChoiceClue(s);
            
            ClueController.Controller.ClearChoice();
        }
    }
}
