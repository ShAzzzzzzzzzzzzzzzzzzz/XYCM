using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Test : MonoBehaviour
{
    //获取需要点击的按钮
    public Button button;

    public void Best()
    {
        //代码实现按钮的点击
        ExecuteEvents.Execute(button.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
    }

    public void ttest()
    {
        Debug.Log("----------aa-----");
    }

}
