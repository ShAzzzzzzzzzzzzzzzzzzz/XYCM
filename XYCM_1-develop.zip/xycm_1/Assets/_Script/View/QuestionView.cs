using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;


public class QuestionView : MonoBehaviour
{
    public QuestionController questionController;
    float appearSpeed = 0.2f;   //����������Ե������ֵ��ٶ�
    int index = 0;
    public GameObject clues;//ѡ��
    public GameObject sayPlayer;//�Ի���
    public GameObject sayPatient;//�Ի���

    public GameObject next;
    public GameObject back;
    public GameObject choiceBtnPrefab;

    public GameObject player;

    public GameObject patient;

    public GameObject title;

    public GameObject getClueBtn;

    private void Awake()
    {
        next = transform.Find("Top/Wang").gameObject;
        back = transform.Find("Top/Back").gameObject;
    }

    private void Start()
    {
        questionController = GetComponent<QuestionController>();
        getClueBtn.GetComponent<Button>().onClick.AddListener(ClickClueBtn);
        getClueBtn.transform.GetChild(0).GetComponent<Text>().text = showClueBtn;
        ClueController.ShowMe();
        ClueController.HideMe();
        ClueController.Controller.allowChoiceNum = 1;
        next.GetComponent<Button>().onClick.AddListener(()=>
        {
            QuestionController.HideMe();
            ClueController.HideMe();
            PulseController.ShowMe();
        });
        back.GetComponent<Button>().onClick.AddListener(()=>
        {
            QuestionController.HideMe();
            ClueController.HideMe();
            LookListenController.ShowMe();
        });
    }
    
    // ���GetClueBtn��ť�Ĳ���
    private string showClueBtn = "��ʾ�ռ�������";
    private string hideClueBtn = "�����ռ�������";
    public void ClickClueBtn()
    {

        if (getClueBtn.transform.GetComponentInChildren<Text>().text == showClueBtn)
        {
            ClueController.Controller.ShowAllChoiceClue(questionController.GetAllClue());
            getClueBtn.transform.GetComponentInChildren<Text>().text = hideClueBtn;
        }
        else
        {
            ClueController.HideMe();
            getClueBtn.transform.GetComponentInChildren<Text>().text = showClueBtn;
        }
        
    }
    
    
    // ��Ⱦ����
    public void ShowTitle(string entitle)
    {
        title.GetComponent<Text>().text = entitle;
    }
    // ��Ⱦ����
    public void ShowCharacter(Sprite playerSprite, Sprite patientSprite)
    {
        player.GetComponent<Image>().sprite = playerSprite;
        patient.GetComponent<Image>().sprite = patientSprite;
        player.SetActive(true);
        patient.SetActive(true);
    }
    
    // ��Ⱦѡ��
    public void ShowChoiceBtn(string[] choices)
    {
        Transform father = transform.Find("Speak");
        int length = choices.Length > 4 ? 4 : choices.Length;
        for (int i = 0; i < length; i++)
        {
            GameObject g = Instantiate(choiceBtnPrefab, father);
            g.transform.GetChild(0).GetComponent<Text>().text = choices[i];
            g.GetComponent<Button>().onClick.AddListener(()=>ChioceClick());
        }

    }
    // ���ѡ��֮��Ĳ���
    public void ChioceClick()
    {
        GameObject gameObject = EventSystem.current.currentSelectedGameObject;
        string title = gameObject.transform.GetComponentInChildren<Text>().text;
        QuestionController.Say say = questionController.GetSayInfo(title);
        currentSay = say;

        if (hideClueBtn == getClueBtn.transform.GetComponentInChildren<Text>().text) ClickClueBtn();
        getClueBtn.GetComponent<Button>().enabled = false;
        
        if (ClueController.Controller == null)
        {
            ClueController.ShowMe();
            ClueController.HideMe();
        }
        
        ClueController.Controller.SetTip(say.Tip);
        ClueController.Controller.HideAllClue();
        if (say != null)
        {
            
            ShowSayCharacter(say.PlayerSay[0],say.PatientSay[0]);

        }
    }
    
    // ��ʾPlayer�ĶԻ���Ի�
    // ��ʾ��Ļ�ٶ�
    private float appearSpead = 0.1f;
    private float waitTime = 0.5f;
    private bool _playercoroutine = false;
    private bool _patientcoroutine = false;
    public int rowMax = 5;
    private bool beginChioce = false;
    public void ShowSayCharacter(string playerSay,string patientSay)
    {
        if(_playercoroutine == false)
            StartCoroutine(ShowText(playerSay,patientSay ,sayPlayer,sayPatient));
    }
    
    // �첽������ʾ�Ի�
    IEnumerator ShowText(string playerSay,string patientSay,GameObject playerGameObject,GameObject patientGameObject)
    {
        _playercoroutine = true;
        _patientcoroutine = true;
        string nowTxt = "";
        playerGameObject.SetActive(true);
        
        int currentLen = 0;
        for (int i = 0; i < playerSay.Length; i++)
        {
            nowTxt += playerSay[i];
            currentLen += 1;
            if (currentLen > rowMax)
            {
                nowTxt += '\n';
                currentLen = 0;
            }
            
            yield return new WaitForSeconds(appearSpead);
            playerGameObject.transform.GetComponentInChildren<Text>().text = nowTxt;
        }

        

        yield return new WaitForSeconds(waitTime);

        patientGameObject.SetActive(true);
        nowTxt = "";
        
        currentLen = 0;
        for (int i = 0; i < patientSay.Length; i++)
        {
            nowTxt += patientSay[i];
            currentLen += 1;
            if (currentLen > rowMax)
            {
                nowTxt += '\n';
                currentLen = 0;
            }
            
            yield return new WaitForSeconds(appearSpead);
            patientGameObject.transform.GetComponentInChildren<Text>().text = nowTxt;
        }
        _playercoroutine = false;
        _patientcoroutine = false;
        
        SwitchChoiceBtn(false);
        ClueController.ShowLast();
        ShowClue();
        beginChioce = true;

    }
    
    // �л�ѡ��ť��ѡ��
    private void SwitchChoiceBtn(bool choice)
    {
        Transform t = transform.Find("Speak");
        int cnt = t.childCount;
        for (int i = 0; i < cnt; i++)
        {
            Transform p = t.GetChild(i);
            p.GetComponent<Button>().enabled = choice;
        }
    }
    
    // ��ʾ����

    private void ShowClue(string[] clues = null)
    {
        
        if(clues != null)
            ClueController.Controller.SetTip(clues);
        ClueController.ShowMe();
        ClueController.Controller.allowChoiceNum = 1;
        ClueController.Controller.SetTip(currentSay.Tip);
        ClueController.Controller.HideUnReDo();
    }
    
    // �Ƿ���ѡ��״̬�������������clue�Ƿ������أ�����������֮�󣬾ͱ���ѡ��Ľ��Ȼ���л�ѡ��״̬
    private QuestionController.Say currentSay = null;
    private void ListenChoiceStatus()
    {
        if (beginChioce)
        {
            if (ClueController.Controller.GetChoice().Count >= 1)
            {
            
                beginChioce = false;
                currentSay.setChoiceTip(ClueController.Controller.GetChoice()[0]);
                SwitchChoiceBtn(true);
                ClueController.Controller.ClearChoice();
                ClueController.Controller.gameObject.SetActive(false);
                getClueBtn.GetComponent<Button>().enabled = true;
                
            }
            
            
        }
    }
    
    // ��������Ƿ�ѡ�����,ѡ���������������
    private void Update()
    {
        ListenChoiceStatus();
    }
    
    
}
