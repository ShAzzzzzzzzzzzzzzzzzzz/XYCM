using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelController : MonoBehaviour
{

    /// <summary>
    /// �ؿ�ҵ���߼�
    /// Controller��
    /// �¼�����
    /// </summary>
    private LevelView levelView;
    private static LevelController controller = null;
    public static LevelController Controller { get { return controller; } }

    private int levelNum = -1;//���ѡ����ʲô�ؿ�
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>("path");
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<LevelController>();

        }
        controller.gameObject.SetActive(true);
        
    }
    public static void HideMe()
    {
        controller.gameObject.SetActive(false);

    }
    void Start()
    {
        levelView = this.gameObject.GetComponent<LevelView>();
        levelView.UpdateInfo(PlayerModel.Data);//�״λ���
        /*�����¼�����*/

        levelView.levelBtn1.onClick.AddListener(LevelBtn1Onclicked);
        levelView.levelBtn2.onClick.AddListener(Leve2Btn1Onclicked);
        levelView.levelBtn3.onClick.AddListener(Leve3Btn1Onclicked);
        levelView.levelBtn4.onClick.AddListener(Leve4Btn1Onclicked);
        levelView.backBtn.onClick.AddListener(HideMe);
        levelView.beginBtn.onClick.AddListener(BeginGameBtn);
    }

    private void LevelBtn1Onclicked()
    {
        levelNum = 1;
        levelView.GraduallyTransformSizeAnim(levelView.levelBtn1, true);     
    }
    private void Leve2Btn1Onclicked()
    {
        levelNum = 2;
        levelView.GraduallyTransformSizeAnim(levelView.levelBtn2, true);
    }
    private void Leve3Btn1Onclicked()
    {
        levelNum = 3;
        levelView.GraduallyTransformSizeAnim(levelView.levelBtn3, true);
    }
    private void Leve4Btn1Onclicked()
    {
        levelNum = 4;
        levelView.GraduallyTransformSizeAnim(levelView.levelBtn4, true);
    }
    private void BeginGameBtn()
    {
        if (LevelValidation(levelNum))//�ж���ѡ�ؿ��Ƿ���Ч
        {
            
            PlayerModel.Data.LoadLevelData("");
            GameController.ShowMe(); 
            LevelController.HideMe();

        }
        else
        {
            Debug.Log("��ѡ��ؿ�!");
        }
        
    }
    private bool LevelValidation(int thisLevelNum)
    {
        string levelState = PlayerModel.Data.LevelSet[thisLevelNum]["state"];
        if (levelState=="unbegin"||levelState=="continue")//��û�������֮ǰ��һ��
        {
            return true;
        }
        else
        {
            return false;
        }

    }
}
