using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DifferentiationController : MonoBehaviour
{
    private PrescriptionView prescriptionVIew;
    private static string path = "Prefabs/Differentiation";
    private static PrescriptionController controller = null;
    public static PrescriptionController Controller
    {
        get
        {
            return controller;
        }
    }
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>(path);
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            
            controller = obj.AddComponent<PrescriptionController>();
            
        }
        controller.gameObject.SetActive(true);
    }
    public static void HideMe()
    {
        controller.gameObject.SetActive(false);
    }


    void Start()
    {
        prescriptionVIew = this.gameObject.GetComponent<PrescriptionView>();


    }


}
