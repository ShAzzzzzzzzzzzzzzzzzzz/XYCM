using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecordController : MonoBehaviour
{
    private RecordView recordView;
    private static string path = "";
    private static RecordController controller = null;
    public static RecordController Controller
    {
        get
        {
            return controller;
        }
    }
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>(path);
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<RecordController>();

        }
        controller.gameObject.SetActive(true);
    }
    public static void HideMe()
    {
        controller.gameObject.SetActive(false);
    }
    // Start is called before the first frame update
    void Start()
    {
        recordView = this.gameObject.GetComponent<RecordView>();

        /*�����¼�����*/
        recordView.backBtn.onClick.AddListener(BackBtnOnclicked);
    }
    private void BackBtnOnclicked()
    {
        //��ת�����������
        HideMe();
    }

}
