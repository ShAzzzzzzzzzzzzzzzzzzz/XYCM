using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PulseController : MonoBehaviour
{
    private PulseView PulseView;
    private static string path = "Prefabs/Pulse";
    private static PulseController controller = null;
    public static PulseController Controller
    {
        get
        {
            return controller;
        }
    }
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>(path);
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<PulseController>();

        }
        controller.gameObject.SetActive(true);
    }
   
    public static void HideMe()
    {
        Destroy(Controller.gameObject);
    }



    void Start()
    {
        PulseView = this.gameObject.GetComponent<PulseView>();
        PulseView.ShowTip();
        PulseView.ShowTitle(_title);
       
    }


    // ��������
    private string _title = "̫���з�֤";

 


}