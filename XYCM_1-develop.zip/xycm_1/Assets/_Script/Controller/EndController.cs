using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndController : MonoBehaviour
{
    private EndView endview;
    private static string path = "";
    private static EndController controller = null;
    public static EndController Controller
    {
        get
        {
            return controller;
        }
    }
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>(path);
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<EndController>();

        }
        controller.gameObject.SetActive(true);
    }
    public static void HideMe()
    {
        controller.gameObject.SetActive(false);
    }


    void Start()
    {
        endview = this.gameObject.GetComponent<EndView>();


    }
}
