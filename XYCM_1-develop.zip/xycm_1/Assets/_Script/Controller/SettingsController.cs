using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingsController : MonoBehaviour
{
    private SettingsView settingsView;
    private static string path = "";
    private static SettingsController controller = null;
    public static SettingsController Controller
    {
        get
        {
            return controller;
        }
    }
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>(path);
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<SettingsController>();

        }
        controller.gameObject.SetActive(true);
    }
    public static void HideMe()
    {
        controller.gameObject.SetActive(false);
    }

    
    void Start()
    {
        settingsView = this.gameObject.GetComponent<SettingsView>();
        

    }

   
    private void MoveBar()
    {
        //ֱ�ӷ���Data�޸�
        
    }
    public void UpdateViewInfo(PlayerModel data)
    {
        if (settingsView != null&&settingsView.isActiveAndEnabled==true)
        {
            settingsView.UpdateInfo(data);
        }
        
    }
    private void OnDestroy()
    {
        
    }
    
}
