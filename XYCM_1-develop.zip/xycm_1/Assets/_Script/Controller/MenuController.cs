using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuController :MonoBehaviour
{
    /// <summary>
    ///�˵�ҵ���߼�
    /// Controller��
    /// �¼�����
    /// </summary>
    
    private MainView mainView;
    private MenuView menuView;
    private static MainController controller = null;

    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>("path");
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<MainController>();

        }
        controller.gameObject.SetActive(true);

    }
    public static void HideMe()
    {
        controller.gameObject.SetActive(false);

    }
    void Start()
    {
       
        menuView = this.gameObject.GetComponent<MenuView>();
        /*�����¼�����*/

        menuView.achievementBtn.onClick.AddListener(AchievementBtnOnclicked);
        menuView.noticeBtn.onClick.AddListener(NoticeBtnOnclicked);
        menuView.aboutusBtn.onClick.AddListener(AboutusBtnOnclicked);
        menuView.moreBtn.onClick.AddListener(MoreBtnOnclicked);
        menuView.closeBtn.onClick.AddListener(HideMe);

    }

    private void AchievementBtnOnclicked()
    {

    }
    private void NoticeBtnOnclicked()
    {

    }
    private void AboutusBtnOnclicked()
    {

    }
    private void MoreBtnOnclicked()
    {

    }
   
}
