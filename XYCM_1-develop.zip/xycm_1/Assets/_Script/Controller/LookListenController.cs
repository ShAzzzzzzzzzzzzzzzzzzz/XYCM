using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LookListenController : MonoBehaviour
{
    private LookListenView lookListenView;
    private static string path = "Prefabs/Look";
    private static LookListenController controller = null;
    public static LookListenController Controller
    {
        get
        {
            return controller;
        }
    }
    public static void ShowMe()
    {
        if (controller == null)//��˵�����״μ���
        {
            //��Ԥ�������ʵ����
            GameObject preObj = Resources.Load<GameObject>(path);
            GameObject obj = Instantiate(preObj);
            //�������ĸ�����Ϊcanvas
            obj.transform.SetParent(GameObject.Find("Canvas").transform, false);
            controller = obj.GetComponent<LookListenController>();
            
        }
        controller.gameObject.SetActive(true);
        controller.transform.SetAsLastSibling();
    }
    public static void HideMe()
    {
        Destroy(Controller.gameObject);
    }

    

    void Start()
    {
         lookListenView= this.gameObject.GetComponent<LookListenView>();
         lookListenView.ShowTip();
         // ����������ѡ������
         ClueController.Controller.allowChoiceNum = 1;
         ClueController.Controller.SetTip(allClue);
         ClueController.Controller.HideUnReDo();
         lookListenView.ShowTitle(_title);
         lookListenView.ShowTongue(_tongue);
         lookListenView.gotoRecordBtn.onClick.AddListener(lookListenView.SwitchNext);
         lookListenView.backBtn.onClick.AddListener(lookListenView.SwitchBack);

         // lookListenView.showClueBtn.GetComponent<Button>().onClick.AddListener(ClickClueBtn);
    }
    
    public void ClickClueBtn()
    {
        string txt = lookListenView.showClueBtn.transform.GetComponentInChildren<Text>().text;
        if (txt == lookListenView.showClueTxt)
        {
            ClueController.ShowMe();
            ClueController.Controller.ShowAllChoiceClue(new []{choiceClue,"",""});
            lookListenView.showClueBtn.transform.GetComponentInChildren<Text>().text = lookListenView.hideClueTxt;
        }
        else
        {
            ClueController.Controller.SetTip(allClue);
            ClueController.Controller.HideAllClue();
            lookListenView.showClueBtn.transform.GetComponentInChildren<Text>().text = lookListenView.showClueTxt;
        }
    }


    // ��������
    private string _title = "̫���з�֤";
    
    // ���ص�����
    public string[] allClue = new []{"�ִ���","������","������"};
    
    // ѡ�������
    public string choiceClue;
    
    // ��ͷSprite
    [SerializeField]
    private Sprite _tongue;

    /// <summary>
    /// ���������Ƿ��Ѿ�ѡ�����
    /// </summary>
    private void ListenChoiceClue()
    {
        if (ClueController.Controller.GetChoice().Count > 0)
        {
            
            choiceClue = ClueController.Controller.GetChoice()[0];
            print(choiceClue);
            int currentIdx = -1;
            
            for (int i = 0; i < allClue.Length; i++)
            {
                if (choiceClue == allClue[i])
                {
                    currentIdx = i;
                    break;
                }
            }
            ClueController.Controller.ShowTheChoice(allClue,new []{currentIdx});
            ClueController.Controller.ClearChoice();
        }
    }
    
    // ��ʾBTN
    private void Update()
    {
        ListenChoiceClue();
    }
}
