﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace _Script.Other
{
    public class DragMove : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        /// <summary>
        /// 开始拖动的委托声明
        /// </summary>
        public delegate void BeginDrag(PointerEventData eventData);

        /// <summary>
        /// 拖动中的委托说明
        /// </summary>
        public delegate void Drag(PointerEventData eventData);
        
        /// <summary>
        /// 拖动结束的委托说明
        /// </summary>
        public delegate void EndDrag(PointerEventData eventData);
        
        
        
        /// <summary>
        /// 开始拖动的委托,在其中增加函数会自动调用委托的函数
        /// </summary>
        public BeginDrag begin = null;

        public Drag ondrog = null;

        public EndDrag endDrag = null;

        

        public void OnBeginDrag(PointerEventData eventData)
        {
            if(begin == null) return;
            begin(eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if(ondrog == null) return;
            ondrog(eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if(endDrag == null) return;
            endDrag(eventData);
        }
        
    }
}

