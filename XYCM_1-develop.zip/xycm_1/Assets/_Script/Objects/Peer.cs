using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Peer
{
    private const string Patient_Image_Default = "";//ϵͳĬ�ϵ�ͼƬ���͹ؿ��޹�
    private const int Peer_Pos_Default =1;//Peerλ��Ĭ��
    private const int Layer_Default = 1;//ͼ�����ȼ������ڵ���ϵ�й�

    private int num;
    private string[] images=null;

    public int Num
    {
        set
        {
            
            if (value >= 0 && value <= 3)
            {
                this.num = value;
                if (value != 0)
                {
                    Init();
                }
            }
            else
            {
                Debug.Log("��ͬ��Ա��Ŀout of range[0,3]!");
            }
        }
        get
        {
            return num;
        }
    }
    public string[] Images
    {
        set
        {
            if (images != null)//����ͬ�ߵ������
            {
                if (value != null && value.Length == num)
                {
                    images = value;
                }
            }
        }
        get
        {
            return images;
        }
    }
    public string[] Id { set; get; } = null;
    public int[] Age { set; get; } = null;
    public string[] Sex { set; get; } = null;
    public string[] Name { set; get; } = null;
    public string[] Animation { set; get; } = null;
    public int[] Pos { set; get; }= null;
    public Peer()
    {
        //Ĭ������Ϊ0
        this.num = 0;
    }
    void Init()
    {
        if (num != 0)
        {
            Id = new string[num];
            Age = new int[num];
            Sex = new string[num];
            Pos = new int[num];
            Name = new string[num];
            Images = new string[num];
            Animation = new string[num];
            if (num == 1)
            {
                Pos[0] = Peer_Pos_Default;//ֻ��һ����ͬ��Ĭ��һ��λ��
            }
        }
        
    }
}
