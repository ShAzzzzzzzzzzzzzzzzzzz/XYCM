using System.Collections;
using System.Collections.Generic;


public class Patient
{
    
    private const string Patient_Image_Default = "";//ϵͳĬ�ϵ�ͼƬ���͹ؿ��޹�
    private const int Patient_Pos_Default = 1;//����λ��Ĭ��
    private const int Layer_Default = 1;//ͼ�����ȼ������ڵ���ϵ�й�


    private string image;
    private int pos;
    public string Id { set; get; }
    public int Age { set; get; }
    public string Sex { set; get; }
    public string Name { set; get; }
    public string Animation { set; get; }
    
    public int Direction{ set; get; }//0Ϊ����1Ϊ����
    public int Pos
    {
        //posֵ��ΧΪ[0,4]
        set
        {
            if (value >= 0 && value <= 4)
            {
                this.pos = value;
                SetDirection();
            }           
        }
        get
        {
            return pos;
        }
    }

    public string Image
    {
        set
        {
            if (string.IsNullOrEmpty(value))
            {
                image = Patient_Image_Default;
            }
            else
            {
                image = value;
            }
        }
        get
        {
            return image;
        }
    }

    public Patient()
    {
        Id = "";
        Age = 1;
        Sex = null;
        Name = null;
        Image = null;
        Animation = null;
        Pos = Patient_Pos_Default;
        SetDirection();
    }
    /// <summary>
    /// ����λ�õ�������
    /// </summary>
    private void SetDirection()
    {
        if (pos >= 0 && pos <= 2)
        {
            Direction = 1;
        }
        else
        {
            Direction = 0;
        }

    }
}