using System.Collections;
using System.Collections.Generic;


public class Doctor
{
    private const string Doctor_Image_Default = "yby";//Ĭ�ϼ���ͼ
    private const int Doctor_Pos_Default =3;//ҽ��λ��Ĭ��
    private const int Layer_Default = 1;//ͼ�����ȼ������ڵ���ϵ�й�

    private int pos;
    private string image;
    public string Id { set; get; }
    public int Age { set; get; }
    public string Sex { set; get; }
    public string Name { set; get; }
    public string Animation { set; get; }
    public int Direction { set; get; }//0Ϊ����1Ϊ����
    public int Layer { set; get; }
    public int Pos
    {
        //posֵ��ΧΪ[0,4]
        set
        {
            if (value >= 0 && value <= 4)
            {
                this.pos = value;
                SetDirection();
            }
        }
        get
        {
            return pos;
        }
    }
    public string Image
    {
        set
        {
            if (string.IsNullOrEmpty(value))
            {
                image = Doctor_Image_Default;
            }
            else
            {
                image = value;
            }
        }
        get
        {
            return image;
        }
    }
    public Doctor()
    {
        Id ="";
        Age = 1;
        Sex = null;
        Name = null;
        Image = Doctor_Image_Default;
        Animation = null;
        Layer = Layer_Default;
        Pos = Doctor_Pos_Default;
    }
    private void SetDirection()
    {
        if (pos >= 0 && pos <= 2)
        {
            Direction = 1;
        }
        else
        {
            Direction = 0;
        }

    }
}