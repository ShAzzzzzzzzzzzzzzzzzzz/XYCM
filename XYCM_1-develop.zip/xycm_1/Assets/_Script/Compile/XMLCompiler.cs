using System.Collections;
using System.Collections.Generic;
using UnityEngine;//��Ҫ��debug.log��ʧЧ
using System.IO;
using System.Xml;
using System;

public class XMLCompiler : MonoBehaviour
{
    string rootXMLPath = @"D:\unity\Compile\XML";
    string fullTXTLevelPath = @"D:\unity\Compile\TXT\Level001.txt";
    string fullTXTAdminPath = @"D:\unity\Compile\TXT\admin.txt";
    bool isGuideMode = false;//����ָ��
    int mode =1; //����ģʽ 0ΪadminData 1ΪlevelData
    // Start is called before the first frame update
    private void xmlLevelCompile(string path)
    {
        string fileType = null;
        string fileName = null;
        if (path != null & path != "" & File.Exists(path))
        {
            Debug.Log("Start compiling...");
            FileStream fs = new FileStream(path, FileMode.OpenOrCreate);
            StreamReader sr = new StreamReader(fs);
            string s = null;
            //����һ��xml
            XmlDocument xmlDoc = new XmlDocument();
            //������������
            XmlDeclaration xmldec = xmlDoc.CreateXmlDeclaration("1.0", "utf-8", null);
            xmlDoc.AppendChild(xmldec);
            //����xml��Ԫ��
            XmlElement xmlRootEle = xmlDoc.CreateElement("Level");
            xmlDoc.AppendChild(xmlRootEle);
            bool isLoopOver = false;
            string xmlContent=null;


            while (isLoopOver != true)//û�������һ��
            {
                s = sr.ReadLine();
                if (s.StartsWith("#END"))
                {
                    isLoopOver = true;
                    continue;
                }
                if (s == null)
                {
                    continue;
                }

                if (s.StartsWith("@"))
                {
                    string docInfo = s.Substring(1);
                    if (docInfo.StartsWith("Type="))
                    {
                        fileType = docInfo.Substring(5);

                    }
                    if (docInfo.StartsWith("Document="))
                    {
                        fileName = docInfo.Substring(9);

                    }
                }


                if (s.StartsWith("[Basic]"))
                {
                    XmlElement basicEle = xmlDoc.CreateElement("Basic");
                    while ((s = sr.ReadLine()).StartsWith("[")!=true )
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("levelId="))
                        {
                            xmlContent = s.Substring(8);
                            Ele = xmlDoc.CreateElement("levelId");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("levelName="))
                        {
                            xmlContent = s.Substring(10);
                            Ele = xmlDoc.CreateElement("levelName");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("levelClass="))
                        {
                            xmlContent = s.Substring(11);
                            Ele = xmlDoc.CreateElement("levelClass");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("isGuideMode="))
                        {
                            xmlContent = s.Substring(12);
                            Ele = xmlDoc.CreateElement("isGuideMode");
                            Ele.InnerText = xmlContent.ToString();
                        }

                        if (Ele != null)
                        {
                            basicEle.AppendChild(Ele);
                        }
                    }
                    if (basicEle != null)
                    {
                        xmlRootEle.AppendChild(basicEle);
                    }
                   
                }

                if (s.StartsWith("[Font]"))
                {
                    XmlElement FontEle = xmlDoc.CreateElement("Font");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("path="))
                        {
                            xmlContent = s.Substring(5);
                            Ele = xmlDoc.CreateElement("path");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("size="))
                        {
                            xmlContent = s.Substring(5);
                            Ele = xmlDoc.CreateElement("size");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (Ele != null)
                        {
                            FontEle.AppendChild(Ele);
                        }
                    }
                    if (FontEle != null)
                    {
                        xmlRootEle.AppendChild(FontEle);
                    }
                }
                if (s.StartsWith("[Patient]"))
                {
                    XmlElement PatientEle = xmlDoc.CreateElement("Patinet");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("patientId="))
                        {
                            xmlContent = s.Substring(10);
                            Ele = xmlDoc.CreateElement("Id");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("patientName="))
                        {
                            xmlContent = s.Substring(12);
                            Ele = xmlDoc.CreateElement("Name");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("patientSex="))
                        {
                            xmlContent = s.Substring(11);
                            Ele = xmlDoc.CreateElement("Sex");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("patientAge="))
                        {
                            xmlContent = s.Substring(11);
                            Ele = xmlDoc.CreateElement("Age");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("patientImage="))
                        {
                            xmlContent = s.Substring(13);
                            Ele = xmlDoc.CreateElement("Image");
                            Ele.InnerText = xmlContent.ToString();

                        }
                        if (s.StartsWith("patientAnimation="))
                        {
                            xmlContent = s.Substring(17);
                            Ele = xmlDoc.CreateElement("Animation");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (Ele != null)
                        {
                            PatientEle.AppendChild(Ele);
                        }
                    }
                    if (PatientEle != null)
                    {
                        xmlRootEle.AppendChild(PatientEle);
                    }
                }

                if (s.StartsWith("[Peer]"))
                {
                    XmlElement PeerEle = xmlDoc.CreateElement("Peer");

                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("peerNum="))
                        {
                            xmlContent = s.Substring(8);
                            Ele = xmlDoc.CreateElement("Num");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("peerId="))
                        {
                            xmlContent = s.Substring(7);
                            Ele = xmlDoc.CreateElement("Id");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("peerImage="))
                        {
                            xmlContent = s.Substring(10);
                            Ele = xmlDoc.CreateElement("Image");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("peerAnimation="))
                        {
                            xmlContent = s.Substring(14);
                            Ele = xmlDoc.CreateElement("Animation");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (Ele != null)
                        {
                            PeerEle.AppendChild(Ele);
                        }
                    }
                    if (PeerEle != null)
                    {
                        xmlRootEle.AppendChild(PeerEle);
                    }
                }
                if (s.StartsWith("[Doctor]"))
                {
                    XmlElement DoctorEle = xmlDoc.CreateElement("Doctor");

                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("doctorId="))
                        {
                            xmlContent = s.Substring(9);
                            Ele = xmlDoc.CreateElement("Id");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("doctorName="))
                        {
                            xmlContent = s.Substring(11);
                            Ele = xmlDoc.CreateElement("Name");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("doctorImage="))
                        {
                            xmlContent = s.Substring(12);
                            Ele = xmlDoc.CreateElement("Image");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (s.StartsWith("doctorAnimation="))
                        {
                            xmlContent = s.Substring(16);
                            Ele = xmlDoc.CreateElement("Animation");
                            Ele.InnerText = xmlContent.ToString();
                        }
                        if (Ele != null)
                        {
                            DoctorEle.AppendChild(Ele);
                        }
                    }
                    if (DoctorEle != null)
                    {
                        xmlRootEle.AppendChild(DoctorEle);
                    }


                }

                if (s.StartsWith("[Dialog]"))
                {
                    XmlElement DialogEle = xmlDoc.CreateElement("Dialog");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            Debug.Log("jump empty");
                            continue;
                            
                        }
                        XmlElement Ele = null;

                        if (s.StartsWith("!"))
                        {
                            xmlContent = s.Substring(1);
                            Ele = xmlDoc.CreateElement("p");
                            //int image_pos = Convert.ToInt32(xmlContent.Substring(0, 1));
                            string image = xmlContent.Substring(1);
                            Ele.InnerText = xmlContent;
                        }
                        else
                        {
                            xmlContent = s;
                            Debug.Log(xmlContent);
                            Ele = xmlDoc.CreateElement("d");
                            //int pos = Convert.ToInt32(xmlContent.Substring(0,1));
                            string text = xmlContent.Substring(1);
                            Ele.InnerText = xmlContent;
                        }
                        if (Ele != null)
                        {
                            DialogEle.AppendChild(Ele);
                        }

                    }
                    if (DialogEle != null)
                    {
                        xmlRootEle.AppendChild(DialogEle);
                    }
                }

                if (s.StartsWith("[EndDialog]"))
                {

                    XmlElement EndDialogEle = xmlDoc.CreateElement("EndDialog");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;

                        if (s.StartsWith("!"))
                        {
                            xmlContent = s.Substring(1);
                            Ele = xmlDoc.CreateElement("p");
                            int image_pos = Convert.ToInt32(xmlContent.Substring(0, 1));
                            string image = xmlContent.Substring(1);
                            Ele.InnerText = xmlContent;
                        }
                        else
                        {
                            xmlContent = s;
                            Ele = xmlDoc.CreateElement("d");                         
                            Ele.InnerText = xmlContent;
                        }
                        if (Ele != null)
                        {
                            EndDialogEle.AppendChild(Ele);
                        }

                    }
                    if (EndDialogEle != null)
                    {
                        xmlRootEle.AppendChild(EndDialogEle);
                    }
                }
                if (s.StartsWith("[Question]"))
                {
                    XmlElement QuestionEle = xmlDoc.CreateElement("Question");
                    XmlElement QEle = xmlDoc.CreateElement("Q");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s)||s.StartsWith("//"))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("Name="))
                        {
                            Ele = xmlDoc.CreateElement("name");
                            xmlContent = s.Substring(5);
                            Ele.InnerText = xmlContent;

                        }
                        else if(s.StartsWith(";"))//��⵽һ���ʴ����
                        {
                            //��QEle�ӵ�QuestionEle��ȥ
                            if (QEle != null)
                            {
                                QuestionEle.AppendChild(QEle);
                            }
                        }
                        else if (s.StartsWith("!"))
                        {
                            //������
                            Ele = xmlDoc.CreateElement("clue");
                            xmlContent = s.Substring(1);
                            Ele.InnerText = xmlContent;
                        }
                        else//�ų����������˵�����ʴ����
                        {
                            Ele = xmlDoc.CreateElement("d");
                            xmlContent = s;

                        }

                        if (Ele != null)
                        {
                            QEle.AppendChild(Ele);
                        }
                    }
                    if (QuestionEle != null)
                    {
                        xmlRootEle.AppendChild(QuestionEle);
                    }
                }

                if (s.StartsWith("[LookListen]"))
                {
                    XmlElement LookListenEle = xmlDoc.CreateElement("LookListen");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s)||s.StartsWith("//"))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("image="))
                        {
                            Ele = xmlDoc.CreateElement("name");

                            xmlContent = s.Substring(6);
                        }
                        if (s.StartsWith("tongue="))
                        {
                            xmlContent = s.Substring(7);
                        }
                        if (s.StartsWith("assembly="))
                        {
                            xmlContent = s.Substring(9);
                        }
                        if (s.StartsWith("clue="))
                        {
                            xmlContent = s.Substring(5);
                        }
                        Ele.InnerText = xmlContent;

                        if (Ele != null)
                        {
                            LookListenEle.AppendChild(Ele);
                        }
                    }
                    if (LookListenEle != null)
                    {
                        xmlRootEle.AppendChild(LookListenEle);
                    }
                }

                if (s.StartsWith("[Clue]"))
                {
                    XmlElement ClueEle = xmlDoc.CreateElement("Clue");

                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement SetEle = xmlDoc.CreateElement("set");
                        XmlElement Ele = null;
                        String[] content = s.Split(",");
                        if (content != null)
                        {
                            int i = 0;
                            foreach(string _s in content)
                            {

                                Ele=(i==0)? xmlDoc.CreateElement("c"): xmlDoc.CreateElement("a");
                                Ele.InnerText = _s;
                                SetEle.AppendChild(Ele);
                                i++;
                            }
                        }
                        if (SetEle != null)
                        {
                            ClueEle.AppendChild(SetEle);
                        }
                    }
                    if (ClueEle != null)
                    {
                        xmlRootEle.AppendChild(ClueEle);
                    }
                }
                if (s.StartsWith("[Pulse]"))
                {
                    XmlElement PulseEle = xmlDoc.CreateElement("Pulse");

                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        if (s.StartsWith("image="))
                        {
                            Ele = xmlDoc.CreateElement("image");
                            xmlContent = s.Substring(6);
                        }
                        if (s.StartsWith("description="))
                        {
                            Ele = xmlDoc.CreateElement("description");
                            xmlContent = s.Substring(12);
                        }
                        if (s.StartsWith("clue="))
                        {
                            Ele = xmlDoc.CreateElement("clue");
                            xmlContent = s.Substring(5);
                        }
                        if (Ele != null)
                        {
                            PulseEle.AppendChild(Ele);
                        }

                    }
                    if (PulseEle != null)
                    {
                        xmlRootEle.AppendChild(PulseEle);
                    }
                }
                if (s.StartsWith("[Prescription]"))
                {
                    XmlElement PrescriptionEle = xmlDoc.CreateElement("Prescription");
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        XmlElement Ele = null;
                        xmlContent = s;
                        Ele.InnerText = xmlContent;

                        if (Ele != null)
                        {
                            PrescriptionEle.AppendChild(Ele);
                        }
                    }
                    if (PrescriptionEle != null)
                    {
                        xmlRootEle.AppendChild(PrescriptionEle);
                    }
                }
                if (s.StartsWith("[EndAnimation]"))
                {
                    while ((s = sr.ReadLine()).StartsWith("[") != true)
                    {
                        if (string.IsNullOrEmpty(s))
                        {
                            continue;
                        }
                        if (s.StartsWith("path="))
                        {
                            xmlContent = s.Substring(5);
                        }
                        if (s.StartsWith("text="))
                        {
                            xmlContent = s.Substring(5);
                        }
                        if (s.StartsWith("#END"))
                        {
                            
                            isLoopOver = true;
                            break;
                        }
                    }
                }            
        }
            //Ҫ��Ҫ��һ���rootEle�ӵ�����
            if (fileName != null)
            {
                string xmlFullPath = rootXMLPath + "\\"+fileType+"_"+fileName;
                xmlDoc.Save(xmlFullPath);
            }
            
            fs.Close();
            sr.Close();           
            fs.Dispose();
            sr.Dispose();
            Debug.Log("Compile finished.");
        }
        else
        {
            Debug.Log("Error:Compiler was unable to find the" + path + " path!");
        }

    }
    private void xmlAdminCompile(string path)
    {

    }
    void Start()
    {
        if (mode==1)
        {
            xmlLevelCompile(fullTXTLevelPath);
        }
        
        
    }
        
    
   
}
