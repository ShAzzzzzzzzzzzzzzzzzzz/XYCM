using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DocumentTest : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(getRootPath());
    }
    private string getRootPath()
    {
        string nowExePath = System.Environment.CurrentDirectory;
        Debug.Log(nowExePath);
        return nowExePath;
    }
}
