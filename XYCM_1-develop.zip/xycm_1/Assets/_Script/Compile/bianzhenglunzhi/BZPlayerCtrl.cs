﻿using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace _Script.Controler.bianzhenglunzhi
{
    public class BZPlayerCtrl : MonoBehaviour
    {
        public static BZPlayerCtrl Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
            }
        }


        
        // debug ------------
        public Transform position;
        //end
        
        // 得到推断位置中可以存放的GameObject
        public Transform GetAspace()
        {
            return position;
        }
    }
}