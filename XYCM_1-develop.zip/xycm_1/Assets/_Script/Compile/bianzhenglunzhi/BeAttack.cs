﻿using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace _Script.Controler.bianzhenglunzhi
{
    public class BeAttack:MonoBehaviour,IPointerDownHandler,IPointerUpHandler
    {
        public Image Image;
        
        
        
        private Color _color;
        private void Start()
        {
            Image = GetComponent<Image>();
            _color = new Color(Image.color.a,Image.color.g,Image.color.b);
            

        }

        // 鼠标按下调用的方法
        public void OnPointerDown(PointerEventData eventData)
        {
            Image.color = Color.red;
            
        }
        // 鼠标抬起之后调用的方法

        public void OnPointerUp(PointerEventData eventData)
        {
            Image.color = _color;
            if (!eventData.dragging)
            {
                Vector3 position;
                position = BZPlayerCtrl.Instance.GetAspace().position;
                Destroy(transform.parent.gameObject);
                
            }

        }
        // 移动到目标位置然后删除和删除逻辑
        private void MoveToCurrent(Vector3 position)
        {
            // transform.;
        }
        
    }
}