﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace _Script.Manager.WxqManeger
{
    /// <summary>
    /// 在人物头上展示对话信息的类
    /// 只需要把相应的预制件移动到人物下面，然后调整
    /// </summary>
    public class HeadSayBox : MonoBehaviour
    {
        // 对话框预制件
        [Tooltip("对话框预制件")]
        public GameObject sayPrefab;

        [SerializeField]private bool beginSay = false;
        
        private Text _sayText;
        
        [SerializeField]private string nowSayText = "";
        private GameObject _sayGameObject;
        // 播放速度
        [SerializeField] public float letterDelay = 0.1f;

        private void ShowPrefab()
        {
            _sayGameObject=Instantiate(sayPrefab, transform.position + new Vector3(0, 4, 0), Quaternion.identity,transform);
            _sayText = _sayGameObject.GetComponentInChildren<Text>();
        }

        private void ShowSay(string s)
        {
            _sayText.text = s;
        }

        private IEnumerator _nowIE;
        private void PullSayText(string s)
        {
            nowSayText = s;
        }
        
        
        IEnumerator ShowDialog(string text)
        {
            _sayText.text = "";
            foreach (char letter in text.ToCharArray())
            {
                _sayText.text += letter;
                yield return new WaitForSeconds(letterDelay);
            }

            StopSay();
        }

        private Coroutine nowCoroutine = null;

        private void StopSay()
        {
            beginSay = false;
        }
        
        /// <summary>
        /// 传入对话信息，就可以开始对话
        /// </summary>
        /// <param name="s">要说的话</param>
        public void BeginSay(string s = null)
        {
            if (s != null) PullSayText(s);
            beginSay = true;
        }

        private void Say()
        {
            if (beginSay)
            {
                beginSay = false;
                if (_sayGameObject == null)
                {
                    ShowPrefab();
                }

                if (nowCoroutine != null)
                {
                    StopCoroutine(nowCoroutine);
                } 
                
                nowCoroutine = StartCoroutine(ShowDialog(nowSayText));
                
            }
        }

        private void Update()
        {
            Say();
        }
    }
}