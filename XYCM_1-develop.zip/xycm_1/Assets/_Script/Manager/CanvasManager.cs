﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace _Script.Manager
{
    public class CanvasManager : MonoBehaviour
    {
        
        
        private void Awake()
        {
            GameController.ShowMe();
        }

        private void Start()
        {
            
        }
        
        
    }
}