using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BookScript : MonoBehaviour
{
    // 当前页的编号
    private int currentPage = 0;
    // 当前页是否为翻开状态
    private bool pageTurning = false;
    // 书本左页的旋转角度
    private float leftPageRotation = 0f;
    // 书本右页的旋转角度
    private float rightPageRotation = 0f;
    // 书本左页的旋转速度
    private float leftPageRotationSpeed = 90f;
    // 书本右页的旋转速度
    private float rightPageRotationSpeed = 90f;
    // 书本左页的GameObject
    public GameObject leftPage;
    // 书本右页的GameObject
    public GameObject rightPage;

    void Update()
    {
        // 使用鼠标或触摸输入来控制书本的翻页
        if (Input.GetMouseButtonDown(0))
        {
            // 获取鼠标点击位置
            Vector3 mousePosition = Input.mousePosition;
            // 如果鼠标点击在书本左侧，则翻到上一页
            if (mousePosition.x < Screen.width / 2)
            {
                currentPage--;
                pageTurning = true;
            }
            // 如果鼠标点击在书本右侧，则翻到下一页
            else
            {
                currentPage++;
                pageTurning = true;
            }
        }

        // 如果当前页处于翻开状态，则更新书本左右两页的旋转角度
        if (pageTurning)
        {
            // 根据当前页的编号来决定左页或右页旋转
            if (currentPage % 2 == 0)
            {
                // 左页旋转
                leftPageRotation += leftPageRotationSpeed * Time.deltaTime;
                if (leftPageRotation >= 0f)
                {
                    leftPageRotation = Mathf.Clamp(leftPageRotation, 0f, 90f);
                    leftPage.transform.localRotation = Quaternion.Euler(0f, 0f, leftPageRotation);
                }
                    
                // 如果左页旋转角度大于等于90度，则翻页结束
                if (leftPageRotation >= 90f)
                {
                    pageTurning = false;
                }
            }
            else
            {
                // 右页旋转
                rightPageRotation -= rightPageRotationSpeed * Time.deltaTime;
                if (rightPageRotation <= -90f)
                {
                    rightPageRotation = -90f;
                }
                rightPage.transform.localRotation = Quaternion.Euler(0f, 0f, rightPageRotation);
                // 如果右页旋转角度小于等于-90度，则翻页结束
                if (rightPageRotation <= -90f)
                {
                    pageTurning = false;
                }
            }
        }
    }
}