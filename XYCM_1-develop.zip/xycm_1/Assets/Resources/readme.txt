Animation=动画+状态机
Prefabs=各种场景预制件
Image=除了人物外的静态图片，如舌图、脉图
Sprites=人物静态精灵图
Test=所有测试的资源存放
XML=关卡和用户数据存放点